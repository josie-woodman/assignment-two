<?php
/**
 * THE HEADER TEMPLATE
 
 */

?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<!-- Linking Custom Styles CSS File -->
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url(home_url('wp-content/themes/budzielite/assets/css/custom-styles.css')); ?>">
	<!-- Linking Google Web Fonts -->
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Hachi+Maru+Pop&family=Montserrat:wght@300;400&display=swap" rel="stylesheet">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<header class="header">
		<nav class="nav-bar">
			<img class="logo" src="<?php echo esc_url(home_url('wp-content/uploads/2021/01/budzie-logo.png')); ?>" alt="logo">
			<?php 
				wp_nav_menu(array(
					'menu' => 'main', //This is the name that I gave the menu when I made it
					'theme_location' => '',
					'depth' => 2,
					'fallback_cb' => false
				));
			?>
		</nav>
	</header>
