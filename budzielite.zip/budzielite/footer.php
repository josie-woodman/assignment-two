<?php
/**
 * THE FOOTER TEMPLATE
 
 */

?>

<footer class="footer">
	<p>&copy Budzie Photography | Proudly Designed by <a class="woodman-studios" href="https://www.woodmanstudios.com">Woodman Studios</a></p>
</footer>


<?php 
	wp_footer();
?>
</body>
</html>